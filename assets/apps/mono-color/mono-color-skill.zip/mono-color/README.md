# Mono Color — core skill package

Original skill: Yan Liu / Dreameryanyan
Source: https://github.com/yanliudesign/mono-color-skill
Packaged from the local skill on 2026-09-09.

This core package includes SKILL.md, its six design-system catalogs, and the original MIT license. The original instructions and catalogs are unchanged. It excludes the upstream artwork and research reference images, which have separate licenses.

Load the mono-color folder in an agent environment that supports SKILL.md and provides image-generation tools. See your agent's documentation for its skill installation directory. The upstream repository contains the full README, evaluation tools and change history.

中文：将 mono-color 文件夹加入支持 SKILL.md 的智能体环境，并启用图像生成工具。具体安装位置见所用环境的说明。此包保留原作者的指令、设计系统与 MIT 许可证；示例图不包含在内。
