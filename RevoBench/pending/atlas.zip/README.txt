打开 index.html 浏览 50 个待开发任务。guide.md 是完整任务说明。
本公开包仅含图册、预览、JSON 与文档，不含原始3D模型或Python构建工具。
完整代码： https://github.com/BrainCoTech/RevoBench （需要仓库权限）。
